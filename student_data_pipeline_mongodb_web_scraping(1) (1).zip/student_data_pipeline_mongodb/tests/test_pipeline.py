from pathlib import Path
import pandas as pd

from app.sources.csv_source import extract_csv
from app.sources.api_source import start_mock_api, extract_api
from app.sources.database_source import extract_database
from app.sources.mongodb_source import extract_mongodb
from app.sources.web_scraping_source import start_mock_web_source, extract_web_scraping
from app.transformation.cleaner import clean_csv_data, clean_web_scraping_data
from app.validation.quality import validate_api_data, validate_database_data, validate_final_data
from app.transformation.integration import integrate_data
from app.transformation.transformer import transform_data

BASE = Path(__file__).resolve().parents[1]

def test_csv_loaded():
    data = extract_csv(BASE / "data/raw/students.csv")
    assert not data.empty

def test_api_connection():
    server, _ = start_mock_api(BASE / "data/raw/api_data.json")
    try:
        data = extract_api(f"http://127.0.0.1:{server.server_port}")
        assert len(data) > 0
    finally:
        server.shutdown()
        server.server_close()

def test_sqlite_extraction():
    data = extract_database(BASE / "database/students.db")
    assert not data.empty

def test_mongodb_extraction():
    data = extract_mongodb(
        "mongodb://localhost:27017",
        "student_pipeline",
        "student_profiles",
        BASE / "data/raw/mongodb_data.json",
        True,
    )
    assert not data.empty


def test_web_scraping_extraction():
    server, _ = start_mock_web_source(BASE / "data/raw/web_scraping_source.html")
    try:
        data = extract_web_scraping(f"http://127.0.0.1:{server.server_port}")
        assert not data.empty
        assert {"student_id", "program", "enrollment_type"}.issubset(data.columns)
    finally:
        server.shutdown()
        server.server_close()

def test_duplicates_removed():
    raw = extract_csv(BASE / "data/raw/students.csv")
    cleaned, duplicates = clean_csv_data(raw)
    assert duplicates > 0
    assert cleaned["student_id"].is_unique

def test_missing_gpa_processed():
    api = pd.DataFrame([
        {"student_id": 1, "gpa": None, "attendance": 80, "status": "Active"},
        {"student_id": 2, "gpa": 3.0, "attendance": 90, "status": "Active"},
    ])
    valid, rejected = validate_api_data(api)
    assert len(valid) == 1
    assert len(rejected) == 1

def test_invalid_records_rejected():
    data = pd.DataFrame([{"student_id": 1, "age": 15, "gpa": 3.0, "attendance": 90}])
    valid, rejected = validate_final_data(data)
    assert valid.empty
    assert len(rejected) == 1

def test_integration():
    csv_data = pd.DataFrame([{"student_id": 1, "student_name": "A", "age": 20, "major": "IT", "city": "Sanaa"}])
    api_data = pd.DataFrame([{"student_id": 1, "gpa": 3.5, "attendance": 90, "status": "Active"}])
    db_data = pd.DataFrame([{"student_id": 1, "course": "Python", "score": 90, "semester": "2026-Fall"}])
    mongo_data = pd.DataFrame([{"student_id": 1, "advisor": "Dr. A", "scholarship": True, "department": "Computing"}])
    web_data = pd.DataFrame([{"student_id": 1, "program": "IT", "enrollment_type": "Regular"}])
    result = integrate_data(csv_data, api_data, db_data, mongo_data, web_data)
    assert len(result) == 1
    assert result.loc[0, "gpa"] == 3.5

def test_final_dataset_created():
    import subprocess, sys
    result = subprocess.run([sys.executable, str(BASE / "main.py")], cwd=BASE, capture_output=True, text=True)
    assert result.returncode == 0
    assert (BASE / "data/processed/final_dataset.csv").exists()
    assert (BASE / "data/rejected/rejected_records.csv").exists()
