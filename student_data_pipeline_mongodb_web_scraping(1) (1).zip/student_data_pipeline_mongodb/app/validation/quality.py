import pandas as pd

def validate_csv_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = df.copy()
    errors = []

    for index, row in data.iterrows():
        reasons = []
        if pd.isna(row.get("student_id")):
            reasons.append("Missing student_id")
        if pd.notna(row.get("age")) and not 16 <= float(row["age"]) <= 80:
            reasons.append("Invalid Age")
        if reasons:
            errors.append({"student_id": row.get("student_id"), "error_reason": "; ".join(reasons), "source": "CSV", "row_index": index})

    rejected = pd.DataFrame(errors, columns=["student_id", "error_reason", "source", "row_index"])
    valid_ids = set(data["student_id"].dropna())
    rejected_ids = set(rejected["student_id"].dropna())
    valid = data[data["student_id"].isin(valid_ids - rejected_ids)].copy()
    return valid, rejected

def validate_api_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = df.copy()
    errors = []
    for index, row in data.iterrows():
        reasons = []
        if pd.isna(row.get("student_id")):
            reasons.append("Missing student_id")
        if pd.isna(row.get("gpa")) or not 0 <= float(row["gpa"]) <= 4:
            reasons.append("Invalid GPA")
        if pd.isna(row.get("attendance")) or not 0 <= float(row["attendance"]) <= 100:
            reasons.append("Invalid Attendance")
        if reasons:
            errors.append({"student_id": row.get("student_id"), "error_reason": "; ".join(reasons), "source": "API", "row_index": index})
    rejected = pd.DataFrame(errors, columns=["student_id", "error_reason", "source", "row_index"])
    rejected_ids = set(rejected["student_id"].dropna())
    valid = data[~data["student_id"].isin(rejected_ids) & data["student_id"].notna()].copy()
    return valid, rejected

def validate_database_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = df.copy()
    errors = []
    for index, row in data.iterrows():
        reasons = []
        if pd.isna(row.get("student_id")):
            reasons.append("Missing student_id")
        if pd.isna(row.get("score")) or not 0 <= float(row["score"]) <= 100:
            reasons.append("Invalid Score")
        if reasons:
            errors.append({"student_id": row.get("student_id"), "error_reason": "; ".join(reasons), "source": "SQLite", "row_index": index})
    rejected = pd.DataFrame(errors, columns=["student_id", "error_reason", "source", "row_index"])
    rejected_ids = set(rejected["student_id"].dropna())
    valid = data[~data["student_id"].isin(rejected_ids) & data["student_id"].notna()].copy()
    return valid, rejected

def validate_mongodb_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = df.copy()
    errors = []
    for index, row in data.iterrows():
        if pd.isna(row.get("student_id")):
            errors.append({"student_id": None, "error_reason": "Missing student_id", "source": "MongoDB", "row_index": index})
    rejected = pd.DataFrame(errors, columns=["student_id", "error_reason", "source", "row_index"])
    valid = data[data["student_id"].notna()].copy()
    return valid, rejected

def validate_final_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = df.copy()
    errors = []
    for index, row in data.iterrows():
        reasons = []
        if pd.isna(row["student_id"]):
            reasons.append("Missing student_id")
        if not 16 <= float(row["age"]) <= 80:
            reasons.append("Invalid Age")
        if not 0 <= float(row["gpa"]) <= 4:
            reasons.append("Invalid GPA")
        if not 0 <= float(row["attendance"]) <= 100:
            reasons.append("Invalid Attendance")
        if reasons:
            errors.append({
                "student_id": row["student_id"],
                "error_reason": "; ".join(reasons),
                "source": "Final Validation",
                "row_index": index,
            })
    rejected = pd.DataFrame(errors, columns=["student_id", "error_reason", "source", "row_index"])
    rejected_ids = set(rejected["student_id"].dropna())
    valid = data[~data["student_id"].isin(rejected_ids) & data["student_id"].notna()].copy()
    return valid, rejected

def validate_web_scraping_data(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = df.copy()
    errors = []
    for index, row in data.iterrows():
        if pd.isna(row.get("student_id")):
            errors.append({
                "student_id": None,
                "error_reason": "Missing student_id",
                "source": "Web Scraping",
                "row_index": index,
            })
    rejected = pd.DataFrame(errors, columns=["student_id", "error_reason", "source", "row_index"])
    valid = data[data["student_id"].notna()].copy()
    return valid, rejected
