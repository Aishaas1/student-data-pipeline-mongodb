import pandas as pd

def integrate_data(
    csv_data: pd.DataFrame,
    api_data: pd.DataFrame,
    database_data: pd.DataFrame,
    mongodb_data: pd.DataFrame,
    web_scraping_data: pd.DataFrame,
) -> pd.DataFrame:
    courses = (
        database_data.groupby("student_id", as_index=False)
        .agg(
            course_count=("course", "count"),
            average_score=("score", "mean"),
            courses=("course", lambda values: ", ".join(sorted(set(values.dropna().astype(str))))),
        )
    )

    result = csv_data.merge(api_data, on="student_id", how="left")
    result = result.merge(courses, on="student_id", how="left")
    result = result.merge(mongodb_data, on="student_id", how="left")
    result = result.merge(web_scraping_data, on="student_id", how="left")
    return result
