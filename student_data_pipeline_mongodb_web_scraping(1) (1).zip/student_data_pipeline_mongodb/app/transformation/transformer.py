import pandas as pd

def transform_data(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy()

    gpa_median = data["gpa"].median()
    attendance_median = data["attendance"].median()
    data["gpa"] = data["gpa"].fillna(gpa_median)
    data["attendance"] = data["attendance"].fillna(attendance_median)
    data["average_score"] = data["average_score"].fillna(data["average_score"].median())
    data["course_count"] = data["course_count"].fillna(0).astype(int)

    data["performance_level"] = pd.cut(
        data["gpa"],
        bins=[-float("inf"), 2.0, 2.5, 3.0, 3.5, float("inf")],
        labels=["At Risk", "Acceptable", "Good", "Very Good", "Excellent"],
        right=False,
    )

    data["attendance_status"] = data["attendance"].apply(
        lambda value: "Good" if value >= 75 else "Low"
    )

    data["source"] = "CSV + API + SQLite + MongoDB + Web Scraping"
    data["gpa"] = data["gpa"].round(2)
    data["attendance"] = data["attendance"].round(2)
    data["average_score"] = data["average_score"].round(2)
    return data
