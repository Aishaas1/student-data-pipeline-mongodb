import pandas as pd

def clean_csv_data(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    data = df.copy()
    data.columns = [str(column).strip().lower().replace(" ", "_") for column in data.columns]
    data["student_id"] = pd.to_numeric(data["student_id"], errors="coerce")
    data["age"] = pd.to_numeric(data["age"], errors="coerce")
    data["student_name"] = data["student_name"].astype("string").str.strip()
    data["major"] = data["major"].astype("string").str.strip()
    data["city"] = data["city"].astype("string").str.strip().str.title()
    duplicates = int(data.duplicated(subset=["student_id"]).sum())
    data = data.drop_duplicates(subset=["student_id"], keep="first")
    return data, duplicates

def clean_api_data(records: list[dict]) -> pd.DataFrame:
    data = pd.DataFrame(records)
    data.columns = [str(column).strip().lower().replace(" ", "_") for column in data.columns]
    for column in ["student_id", "gpa", "attendance"]:
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data["status"] = data["status"].astype("string").str.strip().str.title()
    return data.drop_duplicates(subset=["student_id"], keep="first")

def clean_database_data(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy()
    data["student_id"] = pd.to_numeric(data["student_id"], errors="coerce")
    data["score"] = pd.to_numeric(data["score"], errors="coerce")
    data["course"] = data["course"].astype("string").str.strip()
    data["semester"] = data["semester"].astype("string").str.strip()
    return data

def clean_mongodb_data(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy()
    data["student_id"] = pd.to_numeric(data["student_id"], errors="coerce")
    data["advisor"] = data["advisor"].astype("string").str.strip()
    data["department"] = data["department"].astype("string").str.strip()
    data["scholarship"] = data["scholarship"].fillna(False).astype(bool)
    return data.drop_duplicates(subset=["student_id"], keep="first")

def clean_web_scraping_data(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy()
    data.columns = [str(column).strip().lower().replace(" ", "_") for column in data.columns]
    data["student_id"] = pd.to_numeric(data["student_id"], errors="coerce")
    data["program"] = data["program"].astype("string").str.strip()
    data["enrollment_type"] = data["enrollment_type"].astype("string").str.strip().str.title()
    return data.drop_duplicates(subset=["student_id"], keep="first")
