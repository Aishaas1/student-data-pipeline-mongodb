import json
from pathlib import Path
import pandas as pd

def extract_mongodb(
    uri: str,
    database_name: str,
    collection_name: str,
    seed_path: str | Path | None = None,
    use_mock: bool = True,
) -> pd.DataFrame:
    if use_mock:
        records = json.loads(Path(seed_path).read_text(encoding="utf-8"))
        return pd.DataFrame(records)

    from pymongo import MongoClient
    client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    client.admin.command("ping")
    records = list(client[database_name][collection_name].find({}, {"_id": 0}))
    client.close()
    if not records:
        raise ValueError("MongoDB collection is empty")
    return pd.DataFrame(records)
