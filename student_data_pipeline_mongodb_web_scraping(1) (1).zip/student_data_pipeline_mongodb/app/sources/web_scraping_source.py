import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pandas as pd
import requests
from bs4 import BeautifulSoup


class MockWebScrapingHandler(BaseHTTPRequestHandler):
    html = ""

    def do_GET(self):
        if self.path in ("/", "/students"):
            body = self.html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        return


def start_mock_web_source(html_path: str | Path):
    MockWebScrapingHandler.html = Path(html_path).read_text(encoding="utf-8")
    server = HTTPServer(("127.0.0.1", 0), MockWebScrapingHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


def extract_web_scraping(base_url: str) -> pd.DataFrame:
    response = requests.get(f"{base_url}/students", timeout=10)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    table = soup.find("table", id="students-table")
    if table is None:
        raise ValueError("Web page does not contain the expected students table")

    rows = table.find_all("tr")
    if not rows:
        raise ValueError("Web page contains an empty students table")

    headers = [cell.get_text(strip=True).lower().replace(" ", "_")
               for cell in rows[0].find_all(["th", "td"])]

    records = []
    for row in rows[1:]:
        cells = [cell.get_text(" ", strip=True) for cell in row.find_all("td")]
        if len(cells) != len(headers):
            continue
        records.append(dict(zip(headers, cells)))

    if not records:
        raise ValueError("Web scraping returned no student records")

    return pd.DataFrame(records)
