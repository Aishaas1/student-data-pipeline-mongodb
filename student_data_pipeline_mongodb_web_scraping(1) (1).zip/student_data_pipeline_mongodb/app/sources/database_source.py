import sqlite3
from pathlib import Path
import pandas as pd

def extract_database(path: str | Path) -> pd.DataFrame:
    with sqlite3.connect(path) as connection:
        query = """
        SELECT
            e.student_id,
            c.course_name AS course,
            e.score,
            e.semester
        FROM enrollments e
        JOIN courses c ON c.course_id = e.course_id
        """
        return pd.read_sql_query(query, connection)
