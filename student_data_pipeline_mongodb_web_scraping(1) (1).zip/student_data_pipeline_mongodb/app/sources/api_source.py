import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import requests

class MockAPIHandler(BaseHTTPRequestHandler):
    data = []

    def do_GET(self):
        if self.path == "/students":
            body = json.dumps(self.data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        return

def start_mock_api(data_path: str | Path):
    data = json.loads(Path(data_path).read_text(encoding="utf-8"))
    MockAPIHandler.data = data
    server = HTTPServer(("127.0.0.1", 0), MockAPIHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread

def extract_api(base_url: str) -> list[dict]:
    response = requests.get(f"{base_url}/students", timeout=10)
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, list) or not data:
        raise ValueError("API returned an empty or invalid response")
    return data
